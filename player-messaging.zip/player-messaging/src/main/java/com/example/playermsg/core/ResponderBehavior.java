package com.example.playermsg.core;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static com.example.playermsg.core.ConversationProtocol.*;

/**
 * Responder side of the conversation.
 *
 * For each non-shutdown message:
 *  - increments internal responderCounter,
 *  - replyPayload = "<receivedPayload>|<responderCounter>"
 *  - sends reply back.
 * Stops on SHUTDOWN.
 */
public class ResponderBehavior implements ConversationBehavior {
    private static final Logger log = LogManager.getLogger(ResponderBehavior.class);
    private final String id;

    public ResponderBehavior(String id) {
        this.id = id;
    }

    @Override
    public void run(Transport transport) throws Exception {
        int responderCounter = 0;

        while (true) {
            MessageEnvelope incoming = transport.receive();
            if (incoming == null) {
                break;
            }

            String payload = incoming.payload();

            if (isShutdown(payload)) {
                log.info("[Responder-{}] Received SHUTDOWN — stopping", id);
                break;
            }

            log.info("[Responder-{}] Received: {}", id, payload);

            responderCounter++;
            String replyPayload = responderReplyPayload(payload, responderCounter);

            MessageEnvelope reply = new MessageEnvelope(
                    id,
                    incoming.from(),
                    responderCounter,
                    replyPayload
            );

            log.info("[Responder-{}] Sending back: {} (counter={})",
                    id, reply.payload(), responderCounter);
            transport.send(reply);
        }
    }
}

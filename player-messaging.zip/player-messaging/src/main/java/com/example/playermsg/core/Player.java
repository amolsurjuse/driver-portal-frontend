package com.example.playermsg.core;

/**
 * Player is the "orchestrator" that runs a given behavior over a given transport.
 * This is the single Player class used in both SP and MP.
 */
public class Player implements Runnable {

    private final String id;
    private final ConversationBehavior behavior;
    private final Transport transport;

    public Player(String id, ConversationBehavior behavior, Transport transport) {
        this.id = id;
        this.behavior = behavior;
        this.transport = transport;
    }

    @Override
    public void run() {
        try (transport) {
            behavior.run(transport);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String id() {
        return id;
    }
}

package com.example.playermsg.core;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static com.example.playermsg.core.ConversationProtocol.*;

/**
 * Initiator side of the conversation.
 *
 * Rules:
 * - Start with payload "Hello".
 * - For each round i = 1..maxMessages:
 *     send currentPayload with counter i,
 *     wait for reply,
 *     log reply,
 *     set currentPayload = reply.payload() for next round.
 * - After maxMessages, send SHUTDOWN.
 */
public class InitiatorBehavior implements ConversationBehavior {
    private static final Logger log = LogManager.getLogger(InitiatorBehavior.class);
    private final String fromId;
    private final String toId;
    private final int maxMessages;

    public InitiatorBehavior(String fromId, String toId, int maxMessages) {
        this.fromId = fromId;
        this.toId = toId;
        this.maxMessages = maxMessages;
    }

    @Override
    public void run(Transport transport) throws Exception {
        String currentPayload = initialPayload();

        for (int i = 1; i <= maxMessages; i++) {
            MessageEnvelope outgoing = new MessageEnvelope(fromId, toId, i, currentPayload);
            log.info("[Initiator-{}] Sent: \"{}\" (counter={})", fromId, outgoing.payload(), outgoing.counter());
            transport.send(outgoing);

            MessageEnvelope reply = transport.receive();
            if (reply == null) {
                throw new IllegalStateException("Connection closed before reply");
            }
            log.info("[Initiator-{}] Received reply: \"{}\"", fromId, reply.payload());
            currentPayload = reply.payload();
        }

        // Send shutdown
        MessageEnvelope shutdown = new MessageEnvelope(fromId, toId, -1, shutdownPayload());
        log.info("[Initiator-{}] Sending SHUTDOWN", fromId);
        transport.send(shutdown);
    }
}

package com.example.playermsg.spprocess;

import com.example.playermsg.core.*;
import com.example.playermsg.multiprocess.MultiProcessMain;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Bootstraps the single-JVM version where both players
 * communicate via an in-memory MessageBus using virtual threads.
 */
public class SingleProcessMain {
    private static final Logger log = LogManager.getLogger(SingleProcessMain.class);

    public static void main(String[] args) throws InterruptedException {
        MessageBus bus = new MessageBus();
        MessagePool pool = new MessagePool(64);

        String initiatorId = "initiatorSp";
        String responderId = "responderSp";

        BlockingQueue<Message> initiatorInbox = bus.register(initiatorId);
        BlockingQueue<Message> responderInbox = bus.register(responderId);

        Transport initiatorTransport =
                new SpTransport(initiatorId, bus, initiatorInbox, pool);
        Transport responderTransport =
                new SpTransport(responderId, bus, responderInbox, pool);

        ConversationBehavior initiatorBehavior =
                new InitiatorBehavior(initiatorId, responderId, 10);
        ConversationBehavior responderBehavior =
                new ResponderBehavior(responderId);

        Player initiator = new Player(initiatorId, initiatorBehavior, initiatorTransport);
        Player responder = new Player(responderId, responderBehavior, responderTransport);

        try (ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor()) {
            executor.submit(initiator);
            executor.submit(responder);

            // Just sleep a bit; in real life you'd coordinate via latch.
            Thread.sleep(3000);
           log.info("[Main-SP] Conversation finished (likely).");
        }
    }
}

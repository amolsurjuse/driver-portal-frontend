package com.example.playermsg.core;

/**
 * Shared protocol for both SP and MP.
 *
 * Rules:
 * - Initiator sends initial payload: "Hello"
 * - Responder replies with "<receivedPayload>|<responderCounter>"
 * - Initiator uses the last reply payload as the next outgoing payload
 *   (it does NOT append its own counter into the payload, only logs counter).
 * - "SHUTDOWN" ends the conversation.
 */
public final class ConversationProtocol {

    private ConversationProtocol() {
    }

    /** Initial payload from initiator. */
    public static String initialPayload() {
        return "Hello";
    }

    /** Build responder reply payload: "<receivedPayload>|<responderCounter>". */
    public static String responderReplyPayload(String receivedPayload, int responderCounter) {
        return receivedPayload + "|" + responderCounter;
    }

    /** Shutdown payload. */
    public static String shutdownPayload() {
        return "SHUTDOWN";
    }

    /** Check if a payload represents shutdown. */
    public static boolean isShutdown(String payload) {
        return shutdownPayload().equals(payload);
    }
}

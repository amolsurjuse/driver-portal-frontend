package com.example.playermsg.multiprocess;

import com.example.playermsg.core.MessageEnvelope;
import com.example.playermsg.core.Transport;

import java.io.*;

/**
 * Multi-process implementation of Transport using a TCP-style line protocol:
 * from|to|counter|payload
 */
public class MpTransport implements Transport {

    private final BufferedReader reader;
    private final BufferedWriter writer;

    public MpTransport(Reader in, Writer out) {
        this.reader = new BufferedReader(in);
        this.writer = new BufferedWriter(out);
    }

    @Override
    public MessageEnvelope receive() throws IOException {
        String line = reader.readLine();
        if (line == null) {
            return null;
        }

        String[] parts = line.split("\\|", 4);
        if (parts.length < 4) {
            throw new IOException("Invalid message line: " + line);
        }

        String from = parts[0];
        String to = parts[1];
        int counter = Integer.parseInt(parts[2]);
        String payload = parts[3];

        return new MessageEnvelope(from, to, counter, payload);
    }

    @Override
    public void send(MessageEnvelope envelope) throws IOException {
        String line = envelope.from() + "|" +
                envelope.to() + "|" +
                envelope.counter() + "|" +
                envelope.payload();
        writer.write(line);
        writer.newLine();
        writer.flush();
    }

    @Override
    public void close() throws IOException {
        reader.close();
        writer.close();
    }
}

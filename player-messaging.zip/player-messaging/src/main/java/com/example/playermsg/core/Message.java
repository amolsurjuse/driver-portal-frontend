package com.example.playermsg.core;

/**
 * A poolable message object for single-process in-memory transport.
 * Mutable by design so it can be reused from a MessagePool.
 */
public class Message {

    private String fromPlayerId;
    private String toPlayerId;
    private String payload;
    private int counter;

    public void set(String fromPlayerId,
                    String toPlayerId,
                    String payload,
                    int counter) {
        this.fromPlayerId = fromPlayerId;
        this.toPlayerId = toPlayerId;
        this.payload = payload;
        this.counter = counter;
    }

    public String fromPlayerId() {
        return fromPlayerId;
    }

    public String toPlayerId() {
        return toPlayerId;
    }

    public String payload() {
        return payload;
    }

    public int counter() {
        return counter;
    }

    @Override
    public String toString() {
        return "Message[from=%s, to=%s, payload=\"%s\", counter=%d]"
                .formatted(fromPlayerId, toPlayerId, payload, counter);
    }
}

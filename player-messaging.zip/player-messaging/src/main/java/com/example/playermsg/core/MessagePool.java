package com.example.playermsg.core;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Simple object pool for Message instances.
 * Reduces allocations by reusing Message objects.
 */
public class MessagePool {

    private final Deque<Message> pool = new ArrayDeque<>();
    private final int maxSize;

    public MessagePool(int maxSize) {
        this.maxSize = maxSize;
        for (int i = 0; i < maxSize; i++) {
            pool.push(new Message());
        }
    }

    public synchronized Message acquire(String from, String to, String payload, int counter) {
        Message msg = pool.poll();
        if (msg == null) {
            msg = new Message();
        }
        msg.set(from, to, payload, counter);
        return msg;
    }

    public synchronized void release(Message msg) {
        if (pool.size() < maxSize) {
            pool.push(msg);
        }
        // else let GC collect
    }
}

package com.example.playermsg.multiprocess;

import com.example.playermsg.core.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * Bootstraps the multi-process version.
 *
 * Usage:
 *   # Terminal 1 (server / responder)
 *   java -cp target/player-messaging-1.0-SNAPSHOT.jar com.example.playermsg.multiprocess.MultiProcessMain server
 *
 *   # Terminal 2 (client / initiator)
 *   java -cp target/player-messaging-1.0-SNAPSHOT.jar com.example.playermsg.multiprocess.MultiProcessMain client
 */
public class MultiProcessMain {
    private static final Logger log = LogManager.getLogger(MultiProcessMain.class);

    private static final int DEFAULT_PORT = 5001;

    public static void main(String[] args) {
        if (args.length == 0) {
            log.error("Usage: MultiProcessMain <server|client>");
            System.exit(1);
        }

        String mode = args[0];
        switch (mode) {
            case "server" -> runServer();
            case "client" -> runClient();
            default -> {
                log.error("Unknown mode: {}", mode);
                System.exit(1);
            }
        }
    }

    private static void runServer() {
        String responderId = "responderMp";
        String initiatorId = "initiatorMp";

        log.info("[Server] Listening on port {}", DEFAULT_PORT);

        try (ServerSocket serverSocket = new ServerSocket(DEFAULT_PORT);
             Socket socket = serverSocket.accept();
             MpTransport transport = new MpTransport(
                     new InputStreamReader(socket.getInputStream()),
                     new OutputStreamWriter(socket.getOutputStream())
             )) {

            log.info("[Server] Client connected: {}", socket.getInetAddress());

            ConversationBehavior responderBehavior = new ResponderBehavior(responderId);
            Player responder = new Player(responderId, responderBehavior, transport);
            responder.run();

        } catch (IOException e) {
            log.error(e.getMessage(), e);
        }

        log.info("[Server] Stopped");
    }

    private static void runClient() {
        String initiatorId = "initiatorMp";
        String responderId = "responderMp";

        log.info("[Client] Connecting to localhost:{}",  DEFAULT_PORT);

        try (Socket socket = new Socket("localhost", DEFAULT_PORT);
             MpTransport transport = new MpTransport(
                     new InputStreamReader(socket.getInputStream()),
                     new OutputStreamWriter(socket.getOutputStream())
             )) {

            ConversationBehavior initiatorBehavior =
                    new InitiatorBehavior(initiatorId, responderId, 10);
            Player initiator = new Player(initiatorId, initiatorBehavior, transport);
            initiator.run();

        } catch (IOException e) {
            log.error(e.getMessage(), e);
        }

        log.info("[Client] Done");
    }
}

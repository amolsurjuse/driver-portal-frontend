package com.example.playermsg.spprocess;

import com.example.playermsg.core.*;

import java.util.concurrent.BlockingQueue;

/**
 * Single-process implementation of Transport,
 * backed by MessageBus + BlockingQueue<Message>.
 */
public class SpTransport implements Transport {

    private final String selfId;
    private final MessageBus bus;
    private final BlockingQueue<Message> inbox;
    private final MessagePool pool;

    public SpTransport(String selfId,
                       MessageBus bus,
                       BlockingQueue<Message> inbox,
                       MessagePool pool) {
        this.selfId = selfId;
        this.bus = bus;
        this.inbox = inbox;
        this.pool = pool;
    }

    @Override
    public MessageEnvelope receive() throws InterruptedException {
        Message msg = inbox.take();
        MessageEnvelope env = new MessageEnvelope(
                msg.fromPlayerId(),
                msg.toPlayerId(),
                msg.counter(),
                msg.payload()
        );
        pool.release(msg);
        return env;
    }

    @Override
    public void send(MessageEnvelope envelope) {
        Message msg = pool.acquire(
                envelope.from(),
                envelope.to(),
                envelope.payload(),
                envelope.counter()
        );
        bus.send(msg);
    }
}

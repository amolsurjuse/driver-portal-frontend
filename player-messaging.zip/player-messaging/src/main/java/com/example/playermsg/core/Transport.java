package com.example.playermsg.core;

/**
 * Port abstraction for sending/receiving messages.
 * Implemented by SP (in-memory) and MP (TCP) adapters.
 */
public interface Transport extends AutoCloseable {

    /**
     * Blocking receive of the next message.
     *
     * @return envelope or null if end-of-stream.
     */
    MessageEnvelope receive() throws Exception;

    /**
     * Send a single message.
     */
    void send(MessageEnvelope envelope) throws Exception;

    @Override
    default void close() throws Exception {
        // no-op by default
    }
}

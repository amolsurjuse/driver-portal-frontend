package com.example.playermsg.core;

/**
 * Logical message representation independent of transport:
 * from, to, counter, payload.
 */
public record MessageEnvelope(String from, String to, int counter, String payload) { }


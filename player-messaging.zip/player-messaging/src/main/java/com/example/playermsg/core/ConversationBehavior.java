package com.example.playermsg.core;

/**
 * Strategy for how a player behaves in the conversation.
 * Implementations: InitiatorBehavior, ResponderBehavior.
 */
public interface ConversationBehavior {
    void run(Transport transport) throws Exception;
}

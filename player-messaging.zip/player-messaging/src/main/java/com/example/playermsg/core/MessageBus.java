package com.example.playermsg.core;

import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * In-memory message router for single-process mode.
 */
public class MessageBus {

    private final Map<String, BlockingQueue<Message>> queues = new ConcurrentHashMap<>();

    public BlockingQueue<Message> register(String playerId) {
        return queues.computeIfAbsent(playerId, id -> new LinkedBlockingQueue<>());
    }

    public void send(Message message) {
        BlockingQueue<Message> queue = queues.get(message.toPlayerId());
        if (queue == null) {
            throw new IllegalStateException("No queue registered for player: " + message.toPlayerId());
        }
        queue.offer(message);
    }
}

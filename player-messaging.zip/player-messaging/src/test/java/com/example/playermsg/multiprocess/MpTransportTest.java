package com.example.playermsg.multiprocess;

import com.example.playermsg.core.MessageEnvelope;
import com.example.playermsg.core.Transport;
import org.junit.jupiter.api.Test;

import java.io.*;

import static org.junit.jupiter.api.Assertions.*;

class MpTransportTest {

    @Test
    void sendShouldWriteProtocolLine() throws Exception {
        StringWriter sw = new StringWriter();
        MpTransport transport = new MpTransport(
                new StringReader(""),
                sw
        );

        MessageEnvelope env = new MessageEnvelope("fromX", "toY", 5, "Payload");
        transport.send(env);

        transport.close();

        String line = sw.toString().trim();
        assertEquals("fromX|toY|5|Payload", line);
    }

    @Test
    void receiveShouldParseProtocolLine() throws Exception {
        String input = "fromX|toY|5|Payload\n";
        MpTransport transport = new MpTransport(
                new StringReader(input),
                new StringWriter()
        );

        MessageEnvelope env = transport.receive();
        assertNotNull(env);
        assertEquals("fromX", env.from());
        assertEquals("toY", env.to());
        assertEquals(5, env.counter());
        assertEquals("Payload", env.payload());
    }
}

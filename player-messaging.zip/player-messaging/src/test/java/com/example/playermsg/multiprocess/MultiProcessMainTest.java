package com.example.playermsg.multiprocess;

import org.junit.jupiter.api.Test;

import java.util.concurrent.*;

import static org.junit.jupiter.api.Assertions.*;

class MultiProcessMainTest {

    @Test
    void serverAndClientShouldCompleteConversation() throws Exception {
        ExecutorService executor = Executors.newFixedThreadPool(2);

        Future<?> serverFuture = executor.submit(() ->
                MultiProcessMain.main(new String[]{"server"}));

        // give server a moment to start
        Thread.sleep(200);

        Future<?> clientFuture = executor.submit(() ->
                MultiProcessMain.main(new String[]{"client"}));

        clientFuture.get(10, TimeUnit.SECONDS);
        serverFuture.get(10, TimeUnit.SECONDS);

        executor.shutdownNow();
        assertTrue(executor.awaitTermination(2, TimeUnit.SECONDS));
    }
}

package com.example.playermsg.core;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MessageEnvelopeTest {

    @Test
    void recordShouldHoldValues() {
        MessageEnvelope env = new MessageEnvelope("fromA", "toB", 42, "Hello");
        assertEquals("fromA", env.from());
        assertEquals("toB", env.to());
        assertEquals(42, env.counter());
        assertEquals("Hello", env.payload());
    }
}

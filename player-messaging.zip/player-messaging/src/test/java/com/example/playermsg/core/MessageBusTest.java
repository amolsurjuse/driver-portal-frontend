package com.example.playermsg.core;

import org.junit.jupiter.api.Test;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

class MessageBusTest {

    @Test
    void registerShouldReturnStableQueuePerPlayer() {
        MessageBus bus = new MessageBus();

        BlockingQueue<Message> q1 = bus.register("p1");
        BlockingQueue<Message> q2 = bus.register("p1");

        assertSame(q1, q2);
    }

    @Test
    void sendShouldDeliverToCorrectQueue() throws Exception {
        MessageBus bus = new MessageBus();
        MessagePool pool = new MessagePool(4);

        BlockingQueue<Message> receiverQ = bus.register("receiver");
        bus.register("sender");

        Message msg = pool.acquire("sender", "receiver", "Hello", 1);
        bus.send(msg);

        Message received = receiverQ.poll(1, TimeUnit.SECONDS);
        assertNotNull(received);
        assertEquals("sender", received.fromPlayerId());
        assertEquals("receiver", received.toPlayerId());
        assertEquals("Hello", received.payload());
        assertEquals(1, received.counter());
    }
}

package com.example.playermsg.core;

import org.junit.jupiter.api.Test;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class InitiatorBehaviorTest {

    static class FakeTransport implements Transport {
        List<MessageEnvelope> sent = new ArrayList<>();
        Deque<MessageEnvelope> replies = new ArrayDeque<>();

        @Override
        public MessageEnvelope receive() {
            return replies.poll();
        }

        @Override
        public void send(MessageEnvelope envelope) {
            sent.add(envelope);
        }
    }

    @Test
    void initiatorShouldSendHelloAndUseRepliesAsNextPayloads() throws Exception {
        FakeTransport transport = new FakeTransport();

        // Prepare replies as responder would send
        transport.replies.add(new MessageEnvelope("resp", "init", 1, "Hello|1"));
        transport.replies.add(new MessageEnvelope("resp", "init", 2, "Hello|1|2"));

        InitiatorBehavior behavior = new InitiatorBehavior("init", "resp", 2);
        behavior.run(transport);

        assertEquals(3, transport.sent.size()); // 2 normal + 1 shutdown

        MessageEnvelope first = transport.sent.get(0);
        MessageEnvelope second = transport.sent.get(1);
        MessageEnvelope shutdown = transport.sent.get(2);

        assertEquals("Hello", first.payload());
        assertEquals(1, first.counter());

        assertEquals("Hello|1", second.payload()); // uses reply payload as next payload
        assertEquals(2, second.counter());

        assertEquals("SHUTDOWN", shutdown.payload());
        assertEquals(-1, shutdown.counter());
    }
}

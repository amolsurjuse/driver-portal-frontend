package com.example.playermsg.spprocess;

import com.example.playermsg.core.*;
import org.junit.jupiter.api.Test;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

class SpTransportTest {

    @Test
    void sendShouldPushEnvelopeToPeerInbox() throws Exception {
        MessageBus bus = new MessageBus();
        MessagePool pool = new MessagePool(8);

        String selfId = "A";
        String peerId = "B";

        BlockingQueue<Message> selfInbox = bus.register(selfId);
        BlockingQueue<Message> peerInbox = bus.register(peerId);

        SpTransport selfTransport = new SpTransport(selfId, bus, selfInbox, pool);

        MessageEnvelope env = new MessageEnvelope(selfId, peerId, 1, "Hello");
        selfTransport.send(env);

        Message received = peerInbox.poll(1, TimeUnit.SECONDS);
        assertNotNull(received);
        assertEquals("Hello", received.payload());
        assertEquals(selfId, received.fromPlayerId());
        assertEquals(peerId, received.toPlayerId());
    }

    @Test
    void receiveShouldReturnEnvelopeFromInbox() throws Exception {
        MessageBus bus = new MessageBus();
        MessagePool pool = new MessagePool(8);

        String selfId = "A";
        String peerId = "B";

        BlockingQueue<Message> selfInbox = bus.register(selfId);
        bus.register(peerId);

        SpTransport selfTransport = new SpTransport(selfId, bus, selfInbox, pool);

        Message msg = pool.acquire(peerId, selfId, "Reply", 2);
        bus.send(msg);

        MessageEnvelope env = selfTransport.receive();
        assertEquals("Reply", env.payload());
        assertEquals(2, env.counter());
        assertEquals(peerId, env.from());
        assertEquals(selfId, env.to());
    }
}

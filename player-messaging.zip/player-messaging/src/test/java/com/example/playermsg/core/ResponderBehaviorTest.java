package com.example.playermsg.core;

import org.junit.jupiter.api.Test;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ResponderBehaviorTest {

    static class FakeTransport implements Transport {

        Deque<MessageEnvelope> incoming = new ArrayDeque<>();
        List<MessageEnvelope> sent = new ArrayList<>();
        boolean closed = false;

        @Override
        public MessageEnvelope receive() {
            return incoming.poll();
        }

        @Override
        public void send(MessageEnvelope envelope) {
            sent.add(envelope);
        }

        @Override
        public void close() {
            closed = true;
        }
    }

    @Test
    void responderShouldAppendCounterAndStopOnShutdown() throws Exception {
        FakeTransport transport = new FakeTransport();

        transport.incoming.add(new MessageEnvelope("init", "resp", 1, "Hello"));
        transport.incoming.add(new MessageEnvelope("init", "resp", 2, "Hello|1"));
        transport.incoming.add(new MessageEnvelope("init", "resp", -1, "SHUTDOWN"));

        ResponderBehavior behavior = new ResponderBehavior("resp");
        behavior.run(transport);

        assertEquals(2, transport.sent.size());
        assertEquals("Hello|1", transport.sent.get(0).payload());
        assertEquals("Hello|1|2", transport.sent.get(1).payload());
    }
}

package com.example.playermsg.core;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ConversationProtocolTest {

    @Test
    void initialPayloadIsHello() {
        assertEquals("Hello", ConversationProtocol.initialPayload());
    }

    @Test
    void responderReplyShouldAppendCounter() {
        assertEquals("Hello|1", ConversationProtocol.responderReplyPayload("Hello", 1));
        assertEquals("Hello|1|2", ConversationProtocol.responderReplyPayload("Hello|1", 2));
    }

    @Test
    void shutdownPayloadAndCheck() {
        assertEquals("SHUTDOWN", ConversationProtocol.shutdownPayload());
        assertTrue(ConversationProtocol.isShutdown("SHUTDOWN"));
        assertFalse(ConversationProtocol.isShutdown("Hello"));
    }
}

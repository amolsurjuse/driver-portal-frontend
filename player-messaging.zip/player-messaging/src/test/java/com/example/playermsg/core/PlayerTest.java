package com.example.playermsg.core;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PlayerTest {

    @Test
    void playerShouldRunBehaviorUsingTransport() {
        class DummyBehavior implements ConversationBehavior {
            boolean runCalled = false;
            @Override
            public void run(Transport transport) {
                runCalled = true;
            }
        }

        class DummyTransport implements Transport {
            @Override
            public MessageEnvelope receive() { return null; }
            @Override
            public void send(MessageEnvelope envelope) { }
        }

        DummyBehavior behavior = new DummyBehavior();
        DummyTransport transport = new DummyTransport();

        Player player = new Player("p1", behavior, transport);
        player.run();

        assertTrue(behavior.runCalled);
    }
}

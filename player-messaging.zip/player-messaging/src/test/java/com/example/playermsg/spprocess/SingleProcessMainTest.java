package com.example.playermsg.spprocess;

import org.junit.jupiter.api.Test;

import java.util.concurrent.*;

import static org.junit.jupiter.api.Assertions.*;

class SingleProcessMainTest {

    @Test
    void singleProcessMainShouldRunWithoutException() throws Exception {
        ExecutorService executor = Executors.newSingleThreadExecutor();

        Future<?> future = executor.submit(() -> {
            try {
                SingleProcessMain.main(new String[0]);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                fail("Interrupted");
            }
        });

        future.get(5, TimeUnit.SECONDS);
        executor.shutdownNow();
        assertTrue(executor.awaitTermination(1, TimeUnit.SECONDS));
    }
}

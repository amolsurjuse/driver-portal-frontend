package com.example.playermsg.core;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MessagePoolTest {

    @Test
    void acquireShouldReturnConfiguredMessage() {
        MessagePool pool = new MessagePool(2);

        Message msg = pool.acquire("fromA", "toB", "Hello", 1);

        assertNotNull(msg);
        assertEquals("fromA", msg.fromPlayerId());
        assertEquals("toB", msg.toPlayerId());
        assertEquals("Hello", msg.payload());
        assertEquals(1, msg.counter());
    }

    @Test
    void releaseAllowsReuseWithinCapacity() {
        MessagePool pool = new MessagePool(1);

        Message msg1 = pool.acquire("fromA", "toB", "Hello", 1);
        pool.release(msg1);

        Message msg2 = pool.acquire("fromC", "toD", "World", 2);

        assertSame(msg1, msg2);
        assertEquals("fromC", msg2.fromPlayerId());
    }
}

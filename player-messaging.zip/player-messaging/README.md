# Player Messaging

A small Java 21 project that simulates two "players" sending messages to each other:

- **Single-process mode**: both players run in the same JVM and communicate via an in-memory message bus.
- **Multi-process mode**: each player runs in a separate JVM and they communicate over TCP.

---

## Requirements

- Java **21**
- Maven **3.9+**
- Unix-like shell (for `run.sh`), or adapt commands for your environment

---

## Build & Run

The project includes a convenience script: `run.sh`.

```bash
chmod +x run.sh
````
---
## 🚀 Run in Single-Process Mode

Both players run in the same JVM and communicate through an in-memory message bus:
```bash
./run.sh spprocess
````

---
## 🚀 Run in Multi-Process Mode (Client/Server)
Open two terminals.

Terminal 1 → Start the server (Responder):
```bash
./run.sh server
````
This starts a TCP server and waits for a connection.
Terminal 2 → Start the client (Initiator):
```bash
./run.sh client
````
This connects to the server and starts the conversation.    

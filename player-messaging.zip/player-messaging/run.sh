#!/bin/bash
set -e

JAR="target/player-messaging-1.0-SNAPSHOT.jar"

echo "Building project with Maven..."
mvn -q -DskipTests clean package dependency:copy-dependencies

if [ ! -f "$JAR" ]; then
  echo "ERROR: JAR not found at $JAR"
  exit 1
fi

echo "Using JAR: $JAR"
echo "Checking for MultiProcessMain class in JAR..."
jar tf "$JAR" | grep com/example/playermsg/multiprocess/MultiProcessMain.class >/dev/null || {
  echo "ERROR: MultiProcessMain.class not found in JAR! Check package structure."
  exit 1
}

echo ""

case "$1" in

  spprocess|"")
    echo "🚀 Running in single-process mode (in-process messaging)..."
    CP="$JAR:target/dependency/*"
    java -cp "$CP" com.example.playermsg.spprocess.SingleProcessMain
    ;;

  server)
    echo "🚀 Starting responder (server) in multi-process mode..."
    echo "⛔ Make sure no other process is using port 5000"
    CP="$JAR:target/dependency/*"
    java -cp "$CP" com.example.playermsg.multiprocess.MultiProcessMain server
    ;;

  client)
    echo "🚀 Starting initiator (client) in multi-process mode..."
    CP="$JAR:target/dependency/*"
    java -cp "$CP" com.example.playermsg.multiprocess.MultiProcessMain client
    ;;

  *)
    echo "Usage: $0 [spprocess|server|client]"
    exit 1
    ;;
esac
